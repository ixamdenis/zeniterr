export default function GalleryCard({ title, image, description }) {
    return (
        <div className="bg-[#140c0b] rounded-2xl overflow-hidden border border-brand-terracotta/40 hover:border-brand-orange transition-all duration-300 shadow-lg hover:shadow-brand-orange/30 hover:-translate-y-1">
            <div className="relative">
                <img
                    src={image}
                    alt={title}
                    className="w-full h-56 object-cover brightness-95 hover:brightness-110 transition-all"
                />
            </div>
            <div className="p-4">
                <h2 className="text-lg font-semibold text-brand-yellow mb-1">
                    {title}
                </h2>
                <p className="text-sm text-gray-200 leading-relaxed">{description}</p>
            </div>
        </div>
    );
}
