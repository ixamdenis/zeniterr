import { NavLink } from "react-router-dom";

export default function Sidebar({ isOpen, onClose }) {
    const linkClasses = ({ isActive }) =>
        `block px-4 py-2 rounded-lg text-sm font-medium tracking-wide transition-all duration-300 ${isActive
            ? "bg-brand-orange text-white shadow-lg shadow-brand-orange/40"
            : "text-brand-yellow hover:bg-brand-terracotta/30 hover:text-white"
        }`;

    return (
        <>
            {/* Fondo oscuro (solo móvil) */}
            {isOpen && (
                <div
                    className="fixed inset-0 bg-black/50 z-20 lg:hidden"
                    onClick={onClose}
                />
            )}

            {/* Sidebar */}
            <aside
                className={`fixed z-30 lg:static w-60 bg-gradient-to-b from-brand-black to-[#1e1311] p-5 transform transition-transform duration-300 shadow-2xl border-r border-brand-terracotta/30
        ${isOpen ? "translate-x-0" : "-translate-x-full"} lg:translate-x-0`}
            >
                <h2 className="text-2xl font-semibold mb-8 text-brand-yellow">
                    Menú
                </h2>
                <nav className="space-y-3">
                    <NavLink to="/galerias" className={linkClasses} onClick={onClose}>
                        📁 Galerías
                    </NavLink>
                    <NavLink to="/compras" className={linkClasses} onClick={onClose}>
                        💳 Compras
                    </NavLink>
                    <NavLink to="/configuracion" className={linkClasses} onClick={onClose}>
                        ⚙️ Configuración
                    </NavLink>
                </nav>
            </aside>
        </>
    );
}
