import { useState } from "react";
import Sidebar from "../components/Sidebar";
import Navbar from "../components/Navbar";
import { Outlet } from "react-router-dom";

export default function DashboardLayout() {
    const [isSidebarOpen, setIsSidebarOpen] = useState(false);

    return (
        <div className="min-h-screen flex bg-brand-black text-white font-sans">
            {/* Sidebar */}
            <Sidebar isOpen={isSidebarOpen} onClose={() => setIsSidebarOpen(false)} />

            {/* Contenido principal */}
            <div className="flex-1 flex flex-col relative">
                <Navbar onMenuClick={() => setIsSidebarOpen(!isSidebarOpen)} />

                {/* Contenido centrado */}
                <main className="flex-1 flex justify-center p-4 sm:p-8 overflow-auto">
                    <div className="w-full max-w-5xl bg-[#1a110f] rounded-2xl shadow-xl p-6 sm:p-10 text-white border border-brand-terracotta/20">
                        <Outlet />
                    </div>
                </main>
            </div>
        </div>
    );
}
