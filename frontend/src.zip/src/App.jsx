import { Routes, Route } from "react-router-dom";
import DashboardLayout from "./layouts/DashboardLayout";
import Dashboard from "./pages/Dashboard";
import GalleryView from "./pages/GalleryView";
import Purchases from "./pages/Purchases";
import Settings from "./pages/Settings";

function App() {
  return (
    <Routes>
      <Route element={<DashboardLayout />}>
        <Route index element={<GalleryView />} />
        <Route path="/" element={<Dashboard />} />
        <Route path="/galerias" element={<GalleryView />} />
        <Route path="/compras" element={<Purchases />} />
        <Route path="/configuracion" element={<Settings />} />
      </Route>
    </Routes>
  );
}

export default App;
