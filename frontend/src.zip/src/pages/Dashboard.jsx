export default function Dashboard() {
    return (
        <div>
            <h1 className="text-2xl font-bold mb-4">Panel de control</h1>
            <p className="text-gray-700">
                Bienvenido al panel principal de tu aplicación 📊
            </p>
        </div>
    );
}
