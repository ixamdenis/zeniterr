export default function Purchases() {
    return (
        <div className="p-6">
            <h1 className="text-2xl font-bold mb-2">Tus compras</h1>
            <p className="text-gray-700">Aquí verás tu historial de compras 💳</p>
        </div>
    );
}
